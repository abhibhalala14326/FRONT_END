import React from 'react'
import { Outlet } from 'react-router-dom'

const LoderData = () => {
  return (
    <div>
      <Outlet/>
    </div>
  )
}

export default LoderData
