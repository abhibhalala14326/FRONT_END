import React from 'react'

const SherhFood = ({btn}) => {
  return (
   <>
   </>
  );
}

export default SherhFood
  