import { useState } from 'react'
import './App.css'
import UseReducer from './COmponents/UseReducer'
import SherhFood from './Components/Project/SherhFood'
import Fooditem from './Components/Project/Fooditem'

function App() {


  return (
    <>
    {/* <UseReducer/> */}

    {/* <SherhFood/> */}
    <Fooditem/>
    </>
  )
}

export default App
