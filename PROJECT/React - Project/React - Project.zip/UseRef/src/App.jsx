import './App.css'
import Counter from './Task/Counter';
import Layout from './Task/Layout';
function App() {


  return (
    <>
     <Layout/>
     {/* <Counter/> */}
    </>
  );
}

export default App
